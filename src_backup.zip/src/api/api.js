// src/api/api.js
const API_BASE_URL = "http://165.22.11.185:8000"; // Adjust the URL based on your backend

export const getBaseUrl = () => API_BASE_URL;
