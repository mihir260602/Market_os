import { CssBaseline, ThemeProvider } from "@mui/material";
import React, { useState } from "react";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import Dashboard from "./Dashboard/Dashboard"; // Import Dashboard from the first file
import Header from "./Dashboard/Header"; // Import the Header component
import Sidebar from "./Dashboard/Sidebar";
import CampaignManager from "./pages/CampaignManager";
import ContactList from "./pages/ContactList";
import EmailAnalytics from "./pages/EmailAnalytics";
import LeadActivity from "./pages/LeadActivity";
import LeadAnalysis from "./pages/LeadAnalysis";
import LeadScoring from "./pages/LeadScoring";
import ReportDashboard from "./pages/ReportDashboard";
import SalesPipeline from "./pages/SalesPipeline";
import TaskManager from "./pages/TaskManager";
import WebsiteAnalytics from "./pages/WebsiteAnalytics";
import theme from "./theme/theme";
import Tickets from "./Tickets/Tickets";
import AudienceSegmentation from "./pages/AudienceSegmentation"
import CampaignBuilder from "./pages/CampaignBuilder";
function App() {
  const [selectedPage, setSelectedPage] = useState("Contact List");

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {/* <Login /> */}
      <Router>
        <div style={{ display: "flex", height: "100vh" }}>
          <Sidebar
            selectedPage={selectedPage}
            setSelectedPage={setSelectedPage}
          />
          <main style={{ padding: "20px", width: "100%", overflowY: "auto" }}>
            <Header /> {/* Add the Header component here */}
            <Routes>
              <Route path="/" element={<Dashboard />} /> {/* Dashboard from first file */}
              <Route path="/report-dashboard" element={<ReportDashboard />} />
              <Route path="/contact-list" element={<ContactList />} />
              <Route path="/lead-activity" element={<LeadActivity />} />
              <Route path="/task-manager" element={<TaskManager />} />
              <Route path="/lead-analysis" element={<LeadAnalysis />}/>
              <Route path="/campaign-manager" element={<CampaignManager />} />
              <Route path="/sales-pipeline" element={<SalesPipeline />} />
              <Route path="/lead-scoring" element={<LeadScoring />} />
              <Route path ="/tickets" element={<Tickets />}/>
              <Route path="/website-analytics" element={<WebsiteAnalytics />} />
              <Route path="/email-analytics" element={<EmailAnalytics />}/>
              <Route path="/audience-segmentation" element={<AudienceSegmentation />} />
              <Route path="/campain-builder" element={<CampaignBuilder />} />
            </Routes>
          </main>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;
