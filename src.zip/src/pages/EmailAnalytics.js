import React from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import { Line, Bar, Pie } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";
import { Email, OpenInNew, BarChart, Cancel } from "@mui/icons-material";

// Register Chart.js components
Chart.register(...registerables);

// Dummy data for individual metrics
const openRateData = {
  labels: ["Campaign 1", "Campaign 2", "Campaign 3", "Campaign 4"],
  datasets: [
    {
      label: "Open Rate",
      data: [65, 70, 75, 80],
      backgroundColor: [
        "rgba(255,99,132,0.6)",
        "rgba(54,162,235,0.6)",
        "rgba(255,206,86,0.6)",
        "rgba(75,192,192,0.6)",
      ],
    },
  ],
};

const clickRateData = {
  labels: ["Campaign 1", "Campaign 2", "Campaign 3", "Campaign 4"],
  datasets: [
    {
      label: "Click Rate",
      data: [40, 50, 55, 60],
      backgroundColor: "rgba(153,102,255,0.6)",
    },
  ],
};

const bounceRateData = {
  labels: ["Campaign 1", "Campaign 2", "Campaign 3", "Campaign 4"],
  datasets: [
    {
      label: "Bounce Rate",
      data: [5, 7, 6, 8],
      borderColor: "rgba(255,99,132,0.6)",
      borderWidth: 2,
      fill: false,
    },
  ],
};

const unsubscribeRateData = {
  labels: ["Campaign 1", "Campaign 2", "Campaign 3", "Campaign 4"],
  datasets: [
    {
      label: "Unsubscribe Rate",
      data: [2, 3, 4, 5],
      borderColor: "rgba(75,192,192,0.6)",
      borderWidth: 2,
      fill: false,
    },
  ],
};

const EmailAnalytics = () => {
  // Dummy data for summary stats
  const summaryStats = {
    totalEmailsSent: 1000,
    totalOpens: 800,
    totalClicks: 300,
    totalUnsubscribes: 50,
  };

  // Dummy data for top performing campaigns
  const topCampaigns = [
    { name: "Campaign 1", openRate: "80%", clickRate: "60%" },
    { name: "Campaign 2", openRate: "75%", clickRate: "55%" },
    { name: "Campaign 3", openRate: "70%", clickRate: "50%" },
    { name: "Campaign 4", openRate: "65%", clickRate: "45%" },
  ];

  return (
    <Box
      sx={{
        padding: "20px",
        backgroundColor: "#f4f4f4",
        minHeight: "100vh",
        ml: "-100px", // Margin-left based on sidebar width (assuming sidebar is 250px wide)
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      {/* Enhanced Header */}
      <Typography
        variant="h4"
        sx={{
          marginBottom: "20px",
          fontWeight: "bold",
          color: "#333",
          textAlign: "center",
          backgroundColor: "rgba(0, 123, 255, 0.1)", // Light background color
          padding: "10px",
          borderRadius: "8px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", // Soft shadow
          width: "80%", // Limit width
          fontSize: "2.5rem", // Larger font size
        }}
      >
        Email Marketing Analytics
      </Typography>

      <Grid container spacing={4} sx={{ width: "100%", maxWidth: "1200px" }}>
        {/* Summary Stats Header */}
        <Grid item xs={12}>
          <Typography
            variant="h5"
            sx={{
              marginBottom: "20px",
              textAlign: "center",
              fontWeight: "bold",
              color: "#ff5722", // Change color for visibility
              textTransform: "uppercase", // Uppercase text
              position: "relative",
              "&::after": {
                content: '""',
                display: "block",
                width: "50px",
                height: "4px",
                backgroundColor: "#ff5722",
                margin: "10px auto",
                borderRadius: "2px",
              },
            }}
          >
            Summary Statistics
          </Typography>
        </Grid>

        <Grid container spacing={2}>
          {/* Total Emails Sent */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{ padding: "16px", backgroundColor: "#e3f2fd", boxShadow: 3 }}
            >
              <CardContent>
                <Email sx={{ fontSize: 40, color: "orange" }} />
                <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                  {summaryStats.totalEmailsSent}
                </Typography>
                <Typography>Total Emails Sent</Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Total Opens */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{ padding: "16px", backgroundColor: "#ffe0b2", boxShadow: 3 }}
            >
              <CardContent>
                <OpenInNew sx={{ fontSize: 40, color: "#ff9800" }} />
                <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                  {summaryStats.totalOpens}
                </Typography>
                <Typography>Total Opens</Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Total Clicks */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{ padding: "16px", backgroundColor: "#c8e6c9", boxShadow: 3 }}
            >
              <CardContent>
                <BarChart sx={{ fontSize: 40, color: "#4caf50" }} />
                <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                  {summaryStats.totalClicks}
                </Typography>
                <Typography>Total Clicks</Typography>
              </CardContent>
            </Card>
          </Grid>

          {/* Total Unsubscribes */}
          <Grid item xs={12} sm={6} md={3}>
            <Card
              sx={{ padding: "16px", backgroundColor: "#ffccbc", boxShadow: 3 }}
            >
              <CardContent>
                <Cancel sx={{ fontSize: 40, color: "#f44336" }} />
                <Typography variant="h6" sx={{ fontWeight: "bold" }}>
                  {summaryStats.totalUnsubscribes}
                </Typography>
                <Typography>Total Unsubscribes</Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>

        {/* Charts Section */}
        <Grid item xs={12}>
          <Grid container spacing={4}>
            {/* Open Rate Pie Chart */}
            <Grid item xs={12} sm={6}>
              <Card
                sx={{
                  transition: "transform 0.3s",
                  "&:hover": { transform: "scale(1.05)" },
                  height: "600px", // Set uniform height
                }}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Open Rate by Campaign
                  </Typography>
                  <Pie data={openRateData} />
                </CardContent>
              </Card>
            </Grid>

            {/* Click Rate Bar Chart */}
            <Grid item xs={12} sm={6}>
              <Card
                sx={{
                  transition: "transform 0.3s",
                  "&:hover": { transform: "scale(1.05)" },
                  height: "600px", // Set uniform height
                }}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Click Rate by Campaign
                  </Typography>
                  <Bar data={clickRateData} />
                </CardContent>
              </Card>
            </Grid>

            {/* Bounce Rate Line Chart */}
            <Grid item xs={12} sm={6}>
              <Card
                sx={{
                  transition: "transform 0.3s",
                  "&:hover": { transform: "scale(1.05)" },
                  height: "400px", // Set uniform height
                }}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Bounce Rate by Campaign
                  </Typography>
                  <Line data={bounceRateData} />
                </CardContent>
              </Card>
            </Grid>

            {/* Unsubscribe Rate Line Chart */}
            <Grid item xs={12} sm={6}>
              <Card
                sx={{
                  transition: "transform 0.3s",
                  "&:hover": { transform: "scale(1.05)" },
                  height: "400px", // Set uniform height
                }}
              >
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Unsubscribe Rate by Campaign
                  </Typography>
                  <Line data={unsubscribeRateData} />
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Grid>

        {/* Top Performing Campaigns */}
        <Grid item xs={12}>
          <Typography
            variant="h6"
            sx={{
              marginBottom: "16px",
              textAlign: "center",
              fontWeight: "bold",
              color: "#ff5722", // Main title color
            }}
          >
            Top Campaigns
          </Typography>
          <TableContainer
            component={Paper}
            sx={{
              boxShadow: 3,
              borderRadius: 2, // Rounded corners for the container
              overflow: "hidden", // Ensures border radius is effective
            }}
          >
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell
                    sx={{
                      fontWeight: "bold",
                      backgroundColor: "#e0f7fa", // Light background for headers
                      color: "#006064",
                      borderBottom: "2px solid #006064", // Darker bottom border
                    }}
                  >
                    Campaign
                  </TableCell>
                  <TableCell
                    sx={{
                      fontWeight: "bold",
                      backgroundColor: "#e0f7fa", // Light background for headers
                      color: "#006064",
                      borderBottom: "2px solid #006064", // Darker bottom border
                    }}
                  >
                    Open Rate
                  </TableCell>
                  <TableCell
                    sx={{
                      fontWeight: "bold",
                      backgroundColor: "#e0f7fa", // Light background for headers
                      color: "#006064",
                      borderBottom: "2px solid #006064", // Darker bottom border
                    }}
                  >
                    Click Rate
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {topCampaigns.map((campaign, index) => (
                  <TableRow
                    key={index}
                    sx={{
                      "&:hover": {
                        backgroundColor: "#b2ebf2", // Light hover effect
                      },
                      transition: "background-color 0.3s ease", // Smooth transition for hover effect
                    }}
                  >
                    <TableCell sx={{ padding: "16px", fontSize: "16px" }}>
                      {campaign.name}
                    </TableCell>
                    <TableCell sx={{ padding: "16px", fontSize: "16px" }}>
                      {campaign.openRate}%
                    </TableCell>
                    <TableCell sx={{ padding: "16px", fontSize: "16px" }}>
                      {campaign.clickRate}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>
    </Box>
  );
};

export default EmailAnalytics;
