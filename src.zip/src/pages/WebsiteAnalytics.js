import { Card, CardContent, Grid, Paper, Typography } from "@mui/material";
import React from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const data = [
  { name: "Day 1", visits: 400, sessions: 240, bounceRate: 45 },
  { name: "Day 2", visits: 300, sessions: 139, bounceRate: 55 },
  { name: "Day 3", visits: 200, sessions: 980, bounceRate: 65 },
  { name: "Day 4", visits: 278, sessions: 390, bounceRate: 35 },
  { name: "Day 5", visits: 189, sessions: 480, bounceRate: 50 },
];

const trafficData = [
  { name: "Search Engines", value: 60 },
  { name: "Direct", value: 25 },
  { name: "Social Media", value: 10 },
  { name: "Other", value: 5 },
];

const sessionDistributionData = [
  { name: "0-100", sessions: 400 },
  { name: "101-200", sessions: 300 },
  { name: "201-300", sessions: 200 },
  { name: "301-400", sessions: 100 },
  { name: "401+", sessions: 50 },
];

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

function WebsiteAnalytics() {
  return (
    <Grid container spacing={2} sx={{ marginLeft: { xs: 0, md: "250px" } }}> {/* Responsive margin */}
      <Grid item xs={12}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
            marginBottom: 2,
          }}
        >
          <Typography variant="h4" align="center">
            Website Analytics
          </Typography>
        </Paper>
      </Grid>

      {/* Metrics Boxes */}
      {[
        {
          title: "Total Visits",
          value: "5,000",
          description: "Total number of visits to the website.",
        },
        {
          title: "Total Sessions",
          value: "1,200",
          description: "Total number of sessions recorded.",
        },
        {
          title: "Bounce Rate",
          value: "45%",
          description:
            "Percentage of visitors who leave after viewing one page.",
        },
        {
          title: "Conversion Rate",
          value: "10%",
          description: "Percentage of visitors who complete a desired action.",
        },
        {
          title: "Avg. Session Duration",
          value: "3:45",
          description: "Average duration of a session in minutes and seconds.",
        },
        {
          title: "Pages per Session",
          value: "4.5",
          description: "Average number of pages viewed per session.",
        },
        {
          title: "New Visitors",
          value: "3,000",
          description: "Number of new visitors to the website.",
        },
        {
          title: "Returning Visitors",
          value: "2,000",
          description: "Number of returning visitors to the website.",
        },
      ].map((metric, index) => (
        <Grid item xs={12} sm={6} md={3} key={index}>
          <Card
            sx={{
              padding: 2,
              borderRadius: 2,
              boxShadow: 3,
              backgroundColor: "white",
              textAlign: "center",
            }}
          >
            <CardContent>
              <Typography variant="h6">{metric.title}</Typography>
              <Typography variant="h4">{metric.value}</Typography>
              <Typography variant="body2" color="textSecondary">
                {metric.description}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}

      {/* Charts */}
      <Grid item xs={12} md={6}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
          }}
        >
          <Typography variant="h6">Visits</Typography>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="visits" stroke="#8884d8" />
            </LineChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
          }}
        >
          <Typography variant="h6">Bounce Rate</Typography>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="bounceRate" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
          }}
        >
          <Typography variant="h6">Sessions</Typography>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="sessions" stroke="#82ca9d" />
            </LineChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
          }}
        >
          <Typography variant="h6">Traffic Sources</Typography>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={trafficData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                fill="#8884d8"
                label
              >
                {trafficData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      <Grid item xs={12} md={6}>
        <Paper
          sx={{
            padding: 2,
            borderRadius: 2,
            boxShadow: 3,
            backgroundColor: "white",
          }}
        >
          <Typography variant="h6">Session Distribution</Typography>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={sessionDistributionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="sessions"
                stroke="#82ca9d"
                fillOpacity={0.3}
                fill="#82ca9d"
              />
            </AreaChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>
    </Grid>
  );
}

export default WebsiteAnalytics;
