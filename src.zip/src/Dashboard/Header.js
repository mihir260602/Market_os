import React, { useState } from "react";
import { BsChevronDown } from "react-icons/bs";
import { FaBell } from "react-icons/fa";
import "./Header.css";

const Header = () => {
    const [notifications] = useState(5);
    const [dropdownOpen, setDropdownOpen] = useState(false);
  
    const toggleDropdown = () => {
      setDropdownOpen(!dropdownOpen);
    };
  
    return (
      <div className="header">
        <div className="header-title">Valuebound</div>
        <div className="search-bar">
          <input type="text" placeholder="Search..." />
        </div>
        <div className="header-right">
          <div className="notifications">
            <FaBell size={24} title="Notifications" />
            {notifications > 0 && (
              <span className="notification-count">{notifications}</span>
            )}
          </div>
          <div className="user-profile" onClick={toggleDropdown}>
            <img
              src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWEhUXFRUVFxUYEhUWFRcWFxYXFhUVFxgYHSggGBolHRcWITEhJSkrLy4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lHSUtKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0vLS0tLS0rKy8tLS0tLS0tLSs3LS0tLTQtLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAYCAwUBB//EAD8QAAEDAQYDBgQFAQcEAwAAAAEAAhEDBAUSITFBUWFxBiKBkaGxMlLB0RMUQmLwI0NygqKy4fEHc5LCFTM0/8QAGgEBAAIDAQAAAAAAAAAAAAAAAAMFAQIEBv/EACoRAAICAQQBAwMEAwAAAAAAAAABAgMRBBIhMUEFE1EiYXEzQpHRFDKh/9oADAMBAAIRAxEAPwDnIiLy57kIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiL1rZRLPCMNpLLPEW8WR+vdA5ugnpt6rTUfTaDifBiQJbn0zU601j8HM9ZSvJ4ihWa8WvcRLGxxqCT9PVSnVI4Ho5p9ln/Fs+DX/Ppz2ZotZrCYJj2WAttOYxtnhK0dNi8MlWpqfUkb0WBqCQJEnTn0Wajaa7JVJPphERYNgiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIDKmwkwoN4Wtjf1EQM88hyy3WqpeWu7OAnvDaSPZca02s1JOBjR+7PyCtdNRtWX2UOt1W97Y9IzF7NzADcIzDZLXE8QRupTr3aYaW93UjT/lcE0jJmG8DHssajDlvzXbhFY5MsjLdRd8LRI2JzUO03xHwNwn7LjvoENLiDEah0fVR7JZDUMNmesrZRSNHOTJle9nPPeMHpC0Vnl3xOJM6krJ1iPAk7p+WdGhW2Ua8myja3AAY8pmODuI4eHFWa6rfjJEzkPCNc/JVVtiO+WSnXWXU3TsRHpqorYRnHDRPRbOuSaZcEXjWkAAiDAkeA+69Xn5Jp4Z62MlJJoIiLBsEREAREQBERAEREAREQBERAEREAUS9D/TOeGSATynMdYUtcW/q5kM0A7x66BT6eG+xI5tXYq6ZM11msDC0EYztDjA8BkVN7P3U10E67YQSfUe8KPddg/FIyJOU5ZZ6TzyX0a5rqFMAwB7eE69SrWyaiedhByOW/s3Te0AjrIz6d3VRHdk2E5DCNJaYPirw1g4LzAJUCul4On2olEf2BDtzykiF1bp7FUqZDnNBI9fJWsFCVv7kma+1FPorr+ztFuQYPf3UWv2daRlA1MD+fyFZHha4WrskjZVw+CnW3su0DITluN+JhcmyXWaLhLZ0MTqvoFYqsXwzvSkbZeQ6Y+Dj9q6zmuFZhzgCMoyywwP5nxXthtbarA9uh1HA7hab4fNIg7RBykHquD2TtRFWpTOjhiH94ZH0I8lrqKlOveu0S6K51Xe2+mWtERVZehERAEREAREQBERAEREAREQBERAFUrxrh1Z2eQMeAy+6tjjAnhmqJVrYiTEcuqsNBHLbKj1aeIxifVuxz6RpgNAmBPFW46L5t/04qYWmZxTwyAAkk/QcSvoVOoXNBiPcqe9cnDQ+DcUa1eYhuQFibSBw81zpN9E7ZKbQyXhpLGhbQeS3hxKlUZEbaI7qJT8qtwJWi1WqN0cZMzuRAtdIjQLgWylJMrtVbe3iFzLQWP0e2eoWNrRtuRWbwoy1zVV7mo/h2oA6EOaOR1+hVutwkkA9CDuqzQP9XvfG2rSHgcQJ/nFTLmuS+xE3tthL7osiIipj0gREQBERAEREAREQBERAEREAREQCFRbLSJfHur0qzabKadUuwmMRjoc8vNWGglzJFR6rDKjIuvZS68LGEnN3edGsagTxO/QK2W+04GF3AZLidmnAsxchCm3rm2OKmt5lg461iOSsWi8K9Zxwy31lazc1scMQf8A5nD6rK130yzd1jDUfwAyHJc+v2nt0loZDS0luFuLvbYjwG41U8F8Ihm15MrPabbRd3wSJ1xEnznMdVbbnvx7oB8Tuq5Ur1QxjjUbVe5oL6YY7E0mMtIJz47LoXRTIqg7RJEEQeEHRLG0Zrjkuda0nDiVK7RXo/MCSTsFfGWbFSOy+b3mHCo8auBIHMrSM9zN3HCONZ7ttlY64Gni4z6La/szWZJ/EzG0H7rbabFahgNNzicJNRr2lgDs4aDqQOLSBMbStP49qp0mk1HVKknGxzWlsbQ4an7roaeDmWM8pkSx1KjKgDjIJhT6tlBqY4zD2Z8j9io9ntIeQXNwu3B48lNzxjmB/llQTeE/wzpqWZRX3RKREVIelCIiAIiIAiIgCIiAIiIAiIgCIiALfbrCHU2PbOINILTvP6gtCs13WcPpNB+X/ZdWleJHDr47oJEK4DhJpfKP/Zw/nRdq00i9oETtIyMLkWSkGWjeSHMmIBw4XA+pVosNPJdlr+rJV1rEcMrtS5HNHcA5y0HPqorbtrg5Bg8HfdXh1EBYOY0LEbJGXFMq9kumqNTHQQPuulZbuDZPxE5krpWiuGjLySzWYluIuicwk3J9mYqK6Jt3UzgdOWWSpV82ECq6d8/FW+lahpiGmqrt5U21KrWk5QZI1nZYUXjI8s57rrcW5F3mVFp3Icw5zz5fZWKw1MB/DcQ4DR2kjmpzwNdlvukNkSj2y6w34RC5tSgcbTwBnzEK82yzgyVV7ZR/q4RvTqHxbhI+q1k24v8ABmuKU038oiIiKqL8IiIAiIgCIiAIiIAiIgCIiAIiIArNcFUGn0kHwMj3VZXV7PVoqYPn0PBw0+oUtMtsjm1UN1f4Jl72gNqUY0GLxxCJ9F17vvARC4XbWjhNJwyEkekhRrFaCM52HqFZY3JMp84eC4utyiWm3wNVxKNrc7JQ72vIUMJdm50wOAGpWYx5wYcklk7WI/E90TnHLnwXLt16zl+YwsAkgEgxkNWnp5qoVb3rV3ODZxbADXMA5jkT/ApVj7PVSCKjm02uDZJILoDsUYddQD/IUyrSfLIPdcuIotV3WhzGk43VmHQmHOB4SMz4rg263AVS6o8gnRmI4WiYkhup6qx3VQo0qIa2p8PxSCNwqzfNwU3vL6dYNMHJ4MTIOvgiSyZkp4Opdtta7SpJ0k65Lvi1ECCfFfLLXY61B2hiO6WkOBA3kaLr3b2hL2sY8zsDuMtCkq/KMRu5xIula2wNZVatdq/r0zxLx5sP2WdauGiCfBcN9Uur0ht+I3zIIKj2PDJPcWUdhERUp6UIiIAiIgCIiAIiIAiIgCIiAIiIAt1jr/hva+JwkGOPJaUQw1lYOx2ivFtpFNrAQQ4kzA/SZXIslSASNhJEZ6/YKRd7ZeG/MHNnhLTmoJBo1Zd8J13Ba7IkcRM+StdNJzhllFrIKqzC+CXZrVDmuOklvUE6/wCn1UPt/RxNpVBtLDw70EeylANwPaMwJLePEe0dM1v7RWPHRY39zfDWfRdC4kmcjW6LRBu253lgNN5pTGbQ058Hcl1//hqoHee7q0A+4KzuEugADKOH8yXbqFxbkS08lrKfJLXFJHEN1gtP9WrO4NNs+i5tuu2DlVqEbdwCfRbrytdsacnEjgyJPjGS0WO0VpH47z4kZH+R5rfPBnes4wRTdTtXOe0ZwAfcKvmi1tfABkCMwdxHpGLzV5t9UBnh4qj1CBWG4E9TtHVbQk2c90Vkk26195+ZJBy8TJ9IXtja51VjhkGmeeiiUnHE7nI8eHqF2bqaMGfxSfBujQeZzPlxWt8ttbZtpY77or7k1ERUJ6kIiIAiIgCIiAIiIAiIgCIiAIiIAtlmoF72sbq4ho6la1ZewV3mpaMf6aYJ/wARyaPdb1x3SUSK6xVwcvgxtV3soYmhpdVboXZ9CBpB+6rV7UnPaXgwQ0vLTu2Tia0cc5j7r6x2jul1ak40iGVg04HFsieDhuF8tr0nkODxhqNlr26dY9wrzbGtLajzLnO5vc8nJqVS0me9lIIBhzHCQ4efvwXfs1rbUotkgZknlhGZXFru7ga+cQcQ1xGTmnOHRnMkmeK55teEGNxlyJyI6LMop9GsZOPZaLBfYpiGjUwJ1ziCeohYXj2lOk8ncch91TKdoBnvGRmBzy/ngoNrtbnGSZmf+FlVI1lfLwXOx38AcTu8Y02iYd0y0XKvW9pkCSJeBwPeJBHjH8KrzrU7UDQCeA29481qq2gugDfwjQKRQRE7ZMsla3VW4RiJBDhOoymDPOFyqdpxOB+XTgotpthNNrZOoMTlkHAZbfG7+SvbssNSoSGjLcnQLEtsVlmYOc3tXLJjKxcXNaJJIDeWYLj6D1VqstLCwN1gZnmo113a2i35nbuj24KcqfV6n3Ppj0j0Wg0bpTnP/Z/8CIi4yxCIiAIiIAiIgCIiAIiIAiIgCIp103TVtD8FJs8XaNaOJKyk28I1lJRWZPggr6h2AsQZZg7eoS8nlo30Hqvbp7B2dgBrTWfvJIZ4NH1VgoUgwBrQABkANAOCstLppQlukUet10Lo7IHtdsZqodqbiFT+pTEVB/mHyn6K6ubIhc2s3UcFZrD4ZVptco+U/l5kEZbtOoO6g2m4absUSJ0zynor/fl0Yj+LTHe/UPmHHqq8GqCcHBnRGSmfOL5uarQ0lzDu3PwKhWegx3xSBtxJX1gUg7LVR7RdFM6tGvBZ9w0dSyfNKFhlzmtIwnIyJnQgZbyBoo1ezvbo0gdNeOZE5r6RR7NUmvxCZ66Tw4KXRuFgziSOKz7hq6cnyyx3S+o7IECdSI9OKutC7vwGtbhLQQHCf1A/qnddutZO9AAnbqVcLTczLRZW0/hqU2gMdwcBBB/aVDfXO+D2+Dq0lsNNYnLz5+D5uizrUnNcWuEOaSCOBGoWCpMYPSJ5CIiGQiIgCIiAIiIAiIgCIiAIpd2XZVrvwUmFx3OjWji47BfR+zvY2lQh9SKtXjHdb/dB9zmpqqJWddHJqdZXQueX8FU7NdkKlch9SadLXTvP6cBzX0u7rvp0WBlNoa0bD3PEqQ1qzJjVWlNEa1wee1Orne+evgKBSrgvcyc2wddWnTyII8lvc+fsudbKBbUp1WjQ4Xj9jtT4ENPgV0EEYnVaodrpwZU0Ba67ZCkRhHNdTlV2+ro/tGCDuOKsxavMIOqkfKwzPTyihUYPL7rdJGma61+XRDsdMZnUceXXh5LiNeuScNrOmE9yM8JK2moA3VahUyWosUZubbno469MH5pPQAn6K0WUxVIGhxH1VauWu1tqa0mCWPwjicp9JVmszP6mWgbn5rtoX0nFqH9RwO3FzYh+YYO8B3wN2jR3Ueyo6+vVIMtOfEar5t2juv8AL1SB8Du8zpObeoP0VX6jptr9yPT7Lr0nV74+1LtdHKREVWXQREQBERAEREARFusllfVeGU2l7joAM+vIc1lJvhGG0llmlWns32OqV4fVmlS2H63jkP0jmfDirF2a7GsoxUrxUqahurGHkP1HmfAK2QrGjRfus/gptX6n+2r+f6NF32GnRYGUmBjRsNzxJ1J5qW0LWTCGoTkPP7KwaSRSttvJsdUA5ngtJcdTqkBa3krXJsomQ0WDzsvaeSVWbrY2NlkdLeY7p8ND5QtpCgWV8VI2cJ/xN/29l0FIsEbWGQ304KxwLXet60KOdSq1p+XEMR6NGZVctHa9zjhs9nc8/M+WjrAz84UiMZLQ+kHCCqt2huoiajRJHxADUfMBxG/JaLNb7dUJ/FimODIGXLMk+a6Vme3UOqE7klxM+yy69ywzCs2vgqTXSpdMZZrs1bsok5MAJk5PcOuUwuZfVk/BZIMtJw56gnnuuWVMksnTG5PgrtqxfmaBacLsbS09XAexX0ehVwt07x1VOsNlFS2UDs0Pef8AC2B6kK7VrOMPNT0f6kF/MjRTqAkmZPOM1zO1FlFamKbe9U+JsbHh45heW+8DRLW4Scc986NI2j5t1lc9nLajajyTicDiP1WbcTi4MxVJ1yU4+D59XoPYcL2uYeDgR7rWvrV9WVlTuVGh4IynUHiDqCqPf3ZOrQBqMBqU9f3NH7gNRzVDdpJQWVyj0un9Qha9suGV1ERchYBERAEREB1bhuKranQwQwHvVCO63l+53JfULkuSlZmYaYzPxPPxOPM8OSnWWzMptDGNDWjIACAFm6oBzV5Rpo18+Ty+q1s73jqPx/Zktb6vDzXhM6+SwLl0nEJWTzksV45YaNomtwPFetq8V4V6FsjOTYTkvWuWLSvSFo010bJmFQEaa7dVX75ZbH5fi4W7inDSerjJ8oVhcsQFvGaRrKOSk2Kx02OzZD93Okv/API5rqig0578V2rRY2uGi5pshb8J8D9CumNiZBKDPGtO+fPdY1ac56H5h7HiFmKmzgQtoW/DI8YNFB+DVo6tzB67qP2gpirZn4YJADxxlhxR5AjxU5uXRZmxBwxA4XcRoeo3WHHKwZUsPJUeytSa069w+7T9Fdwcuqp9iun8rayBlTew4ROTXBzS5ue0ER4jZW5mYUVcdqwya2W55RCt9FpaSRMEHx0nyJWVmrtjC4SOCiXvaYLKTficcTuTG5z4uAHmsabCt2kyLo6NrrQ5gPHJdZjwQuLWp48HEFTmkgLklHnB0ReSpdouyYcXVLPk6STT/Sc/0HY8tOipVSmWktcCCDBBEEHgV9YqVcz1XHvu7GVx3hDgMnjUcjxHJcN+iUuYcMtdL6i4fTZyvn4PnqKVb7A+kYcMtnDQ/booqq5RcXhl5CcZrdF5QREWpsfdn6LQ1EXpWeLNgWty8REDJeOREZtE1OWTURZiD0LYvUWWDW5eFEUHkkZ6FDdqURTQIn2abT8JUagvUXRWQzNjtFKsmhRFKRMp/wD1H/sP++z/AEVlM7E/DU6oijfZIujyv/8Atq/3Kf8ApK6NNERBk6z6qUiLmu7J6ujnVNVrqIi18GyOFf3/ANNToPdUtEVTr/1F+C/9L/Sf5YREXCWR/9k=" // Path to user's avatar
              alt="User Avatar"
              className="avatar"
            />
            {/* <img alt="User Avatar" className="avatar" /> */}
            <span className="username">Neeraj Kumar </span>
            <BsChevronDown className="dropdown-icon" />
            {dropdownOpen && (
              <div className="dropdown-menu">
                
                <div className="dropdown-item">Logout</div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  export default Header;